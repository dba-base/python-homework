__author__ = "xiaoyu hao"

import datetime

i = datetime.datetime.now()

print(i.year)
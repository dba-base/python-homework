'''
课程类
'''

class Course(object):

    #定义课程名，课程价格，课程周期
    def __init__(self,course_name,course_price,course_cycle):
        self.course_name = course_name
        self.course_price = course_price
        self.course_cycle = course_cycle



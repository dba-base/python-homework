__author__ = "xiaoyu hao"

import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,BASE_DIR)
#数据文件名称
data_path = os.path.join(BASE_DIR,'data')
school_file = os.path.join(data_path,'school')





